<?php
/**
 * Plugin Name: Woo Order Complete Message
 * Description: Prints "Woo Completed" message when an order is completed.
 * Version: 1.0.0
 * Author: Your Name
 */

 // Exit if accessed directly

    if (!defined('ABSPATH')) {
        exit;
    }

    // Check if WooCommerce is active
    if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
        function woo_order_complete_message($order_id) {
            $order = wc_get_order($order_id);
            $order_status = $order->get_status();

            if ($order_status == 'processing') {
                //javascript alert
                echo '<script>alert("Woo Completed");</script>';
            }
        }
        add_action('woocommerce_order_status_completed', 'woo_order_complete_message');
    }   